<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/helper.php';

$orders = ModOrderStatusUpdaterHelper::getOrders();
$orderStatuses = ModOrderStatusUpdaterHelper::getOrderStatuses();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['new_status'])) {
    ModOrderStatusUpdaterHelper::updateOrderStatus($_POST['order_id'], $_POST['new_status']);
}

require JModuleHelper::getLayoutPath('mod_order_status_updater');
