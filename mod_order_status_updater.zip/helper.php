<?php
defined('_JEXEC') or die;

class ModOrderStatusUpdaterHelper {
    public static function getOrderStatuses() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        
        // Türkçe durum isimleri
        $durumlar = array(
            'created' => 'Oluşturuldu',
            'confirmed' => 'Onaylandı',
            'shipped' => 'Kargoya Verildi',
            'delivered' => 'Teslim Edildi',
            'cancelled' => 'İptal Edildi',
            'refunded' => 'İade Edildi',
            'pending' => 'Beklemede'
        );
        
        $query->select('orderstatus_namekey, orderstatus_name, orderstatus_published, orderstatus_ordering')
              ->from('#__hikashop_orderstatus')
              ->where('orderstatus_published = 1')
              ->order('orderstatus_ordering ASC');
              
        $db->setQuery($query);
        $results = $db->loadObjectList();
        
        // Durum isimlerini Türkçeleştir
        foreach($results as $result) {
            if(isset($durumlar[$result->orderstatus_namekey])) {
                $result->orderstatus_name = $durumlar[$result->orderstatus_namekey];
            }
        }
        
        return $results;
    }
    
    public static function updateOrderStatus($order_id, $new_status) {
        $db = JFactory::getDbo();
        $app = JFactory::getApplication();
        
        try {
            // Sipariş durumunu güncelle
            $query = $db->getQuery(true);
            $query->update('#__hikashop_order')
                  ->set('order_status = ' . $db->quote($new_status))
                  ->set('order_modified = ' . time())
                  ->where('order_id = ' . (int)$order_id);
                  
            $db->setQuery($query);
            $result = $db->execute();
            
            if ($result) {
                $app->enqueueMessage('Sipariş durumu başarıyla güncellendi.', 'success');
                return true;
            } else {
                throw new Exception('Sipariş durumu güncellenirken bir hata oluştu.');
            }
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
            return false;
        }
    }
    
    public static function getOrders() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        
        $query->select('o.*, hu.user_cms_id, u.username, huser.user_email')
              ->from('#__hikashop_order AS o')
              ->join('LEFT', '#__hikashop_user AS hu ON o.order_user_id = hu.user_id')
              ->join('LEFT', '#__users AS u ON hu.user_cms_id = u.id')
              ->join('LEFT', '#__hikashop_user AS huser ON o.order_user_id = huser.user_id')
              ->order('o.order_created DESC')
              ->setLimit(50);
              
        $db->setQuery($query);
        return $db->loadObjectList();
    }
}
