<?php
defined('_JEXEC') or die;
?>

<div class="order-status-updater<?php echo $moduleclass_sfx; ?>">
    <h3>Sipariş Durumu Güncelleme</h3>
    
    <?php if (!empty($orders)) : ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sipariş ID</th>
                        <th>Müşteri</th>
                        <th>Tutar</th>
                        <th>Mevcut Durum</th>
                        <th>Yeni Durum</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) : ?>
                        <tr>
                            <td><?php echo $order->order_id; ?></td>
                            <td><?php echo $order->username ?: 'Misafir Kullanıcı'; ?></td>
                            <td><?php echo number_format($order->order_full_price, 2, ',', '.') . '₺'; ?></td>
                            <td><?php 
                                $durumlar = array(
                                    'created' => 'Oluşturuldu',
                                    'confirmed' => 'Onaylandı',
                                    'shipped' => 'Kargoya Verildi',
                                    'delivered' => 'Teslim Edildi',
                                    'cancelled' => 'İptal Edildi',
                                    'refunded' => 'İade Edildi',
                                    'pending' => 'Beklemede'
                                );
                                echo isset($durumlar[$order->order_status]) ? $durumlar[$order->order_status] : $order->order_status;
                            ?></td>
                            <td>
                                <form action="" method="post" class="form-inline status-update-form">
                                    <input type="hidden" name="order_id" value="<?php echo $order->order_id; ?>">
                                    <select name="new_status" class="form-control">
                                        <?php foreach ($orderStatuses as $status) : ?>
                                            <option value="<?php echo $status->orderstatus_namekey; ?>"
                                                <?php echo ($order->order_status == $status->orderstatus_namekey) ? 'selected' : ''; ?>>
                                                <?php echo $status->orderstatus_name; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="btn btn-primary btn-sm">Güncelle</button>
                                    <span class="update-message"></span>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else : ?>
        <div class="alert alert-info">Henüz sipariş bulunmamaktadır.</div>
    <?php endif; ?>
</div>

<style>
.order-status-updater {
    padding: 15px;
}
.order-status-updater .form-inline {
    display: flex;
    gap: 10px;
}
.order-status-updater select {
    min-width: 150px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.status-update-form').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const statusCell = this.closest('tr').querySelector('td:nth-child(4)');
            const messageSpan = this.querySelector('.update-message');
            const submitButton = this.querySelector('button[type="submit"]');
            
            submitButton.disabled = true;
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                // Durumu güncelle
                statusCell.textContent = formData.get('new_status');
                messageSpan.textContent = '✓ Güncellendi';
                messageSpan.style.color = 'green';
                
                setTimeout(() => {
                    messageSpan.textContent = '';
                }, 3000);
            })
            .catch(error => {
                messageSpan.textContent = '❌ Hata oluştu';
                messageSpan.style.color = 'red';
            })
            .finally(() => {
                submitButton.disabled = false;
            });
        });
    });
});
</script>
