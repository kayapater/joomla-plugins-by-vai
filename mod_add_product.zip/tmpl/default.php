<?php
defined('_JEXEC') or die;

$uri = JUri::getInstance();
$current_url = $uri->toString();

$doc = JFactory::getDocument();
$doc->addScript('https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js');

?>
<div class="add-product-form">
    <h3>Yeni Ürün Ekle</h3>
    <form action="<?php echo $current_url; ?>" method="POST" enctype="multipart/form-data" onsubmit="return prepareSubmit();" id="addProductForm">
        <div>
            <label for="product_name">Ürün Adı:</label>
            <input type="text" id="product_name" name="product_name" required>
        </div>
        <div>
            <label for="product_description">Ürün Açıklaması:</label>
            <textarea id="product_description" name="product_description" required></textarea>
        </div>
        <div>
            <label for="product_quantity">Ürün Adedi:</label>
            <input type="number" id="product_quantity" name="product_quantity" min="0" required>
        </div>
        <div>
            <label for="product_sort_price">Ürün Fiyatı:</label>
            <div class="price-input-wrapper">
                <input type="number" 
                       step="0.01" 
                       id="product_sort_price" 
                       name="product_sort_price" 
                       required 
                       min="0"
                       onchange="formatPrice(this.value)"
                       placeholder="0.00">
                <span class="currency-symbol">₺</span>
            </div>
            <small>Lütfen Türk Lirası cinsinden giriniz</small>
        </div>
        <div>
            <label for="product_image">Ürün Resmi:</label>
            <input type="file" id="product_image" name="product_image" accept="image/*">
            <small>Önerilen boyut: 800x800 piksel</small>
        </div>
        <div>
            <button type="submit" onclick="return validateForm();">Ürün Ekle</button>
        </div>
    </form>
</div>

<style>
.add-product-form {
    max-width: 500px;
    margin: 20px auto;
    padding: 20px;
    background: #f5f5f5;
    border-radius: 5px;
}

.add-product-form div {
    margin-bottom: 15px;
}

.add-product-form label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.add-product-form input,
.add-product-form textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.add-product-form input[type="file"] {
    padding: 4px;
}

.add-product-form small {
    display: block;
    color: #666;
    margin-top: 4px;
}

.add-product-form button {
    background: #2196F3;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.add-product-form button:hover {
    background: #1976D2;
}

.price-input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.currency-symbol {
    position: absolute;
    right: 10px;
    color: #666;
}

#product_sort_price {
    padding-right: 25px;
}
</style>

<script>
function formatPrice(value) {
    const price = parseFloat(value);
    if (!isNaN(price)) {
        document.getElementById('product_sort_price').value = price.toFixed(2);
    }
}

function validateForm() {
    console.log('Form doğrulama başladı');
    
    const editorData = editor.getData();
    document.getElementById('product_description').value = editorData;
    console.log('CKEditor içeriği:', editorData);
    
    return true;
}

function prepareSubmit() {
    console.log('Form gönderimi hazırlanıyor');
    return validateForm();
}

let editor;
ClassicEditor
    .create(document.querySelector('#product_description'), {
        toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'undo', 'redo'],
        placeholder: 'Ürün açıklamasını buraya giriniz...'
    })
    .then(newEditor => {
        editor = newEditor;
    })
    .catch(error => {
        console.error(error);
    });
</script>
