<?php
class ModAddProductHelper {
    public static function addProduct($data) {
        $app = JFactory::getApplication();
        $db = JFactory::getDbo();
        
        try {
            error_log('Gelen form verileri: ' . print_r($data, true));
            
            if (empty($data['product_name']) || empty($data['product_description']) || empty($data['product_quantity']) || empty($data['product_sort_price'])) {
                error_log('Eksik form verileri tespit edildi');
                throw new Exception('Lütfen tüm zorunlu alanları doldurun.');
            }

            $hikashop_path = JPATH_ADMINISTRATOR . '/components/com_hikashop/helpers/helper.php';
            if (!file_exists($hikashop_path)) {
                error_log('HikaShop helper dosyası bulunamadı: ' . $hikashop_path);
                throw new Exception('HikaShop helper dosyası bulunamadı: ' . $hikashop_path);
            }

            include_once($hikashop_path);
            
            if (!function_exists('hikashop_get')) {
                error_log('HikaShop fonksiyonları yüklenemedi');
                throw new Exception('HikaShop fonksiyonları yüklenemedi');
            }

            $query = $db->getQuery(true);
            $columns = array(
                'product_name',
                'product_description',
                'product_quantity',
                'product_published',
                'product_type',
                'product_code',
                'product_created',
                'product_modified'
            );

            $values = array(
                $db->quote($data['product_name']),
                $db->quote($data['product_description']),
                (int)$data['product_quantity'],
                1,
                $db->quote('main'),
                $db->quote('PRD-' . date('Ymd') . '-' . rand(1000, 9999)),
                time(),
                time()
            );

            $query->insert($db->quoteName('#__hikashop_product'))
                  ->columns($db->quoteName($columns))
                  ->values(implode(',', $values));

            $db->setQuery($query);
            $db->execute();
            
            $product_id = $db->insertid();

            if($product_id) {
                $price = (float)$data['product_sort_price'];
                $query = $db->getQuery(true);
                
                $currencyQuery = $db->getQuery(true)
                    ->select($db->quoteName('currency_id'))
                    ->from($db->quoteName('#__hikashop_currency'))
                    ->where($db->quoteName('currency_code') . ' = ' . $db->quote('TRY'));
                
                $db->setQuery($currencyQuery);
                $tryId = $db->loadResult();
                
                if (!$tryId) {
                    $currencyInsert = $db->getQuery(true);
                    $currencyColumns = array(
                        'currency_name',
                        'currency_code',
                        'currency_symbol',
                        'currency_published',
                        'currency_locale'
                    );
                    $currencyValues = array(
                        $db->quote('Turkish Lira'),
                        $db->quote('TRY'),
                        $db->quote('₺'),
                        1,
                        $db->quote('tr-TR')
                    );

                    $currencyInsert->insert($db->quoteName('#__hikashop_currency'))
                        ->columns($db->quoteName($currencyColumns))
                        ->values(implode(',', $currencyValues));

                    $db->setQuery($currencyInsert);
                    $db->execute();
                    $tryId = $db->insertid();
                }

                $columns = array(
                    'price_product_id',
                    'price_value',
                    'price_currency_id',
                    'price_min_quantity'
                );
                $values = array(
                    $product_id,
                    $price,
                    $tryId,
                    0
                );

                $query->insert($db->quoteName('#__hikashop_price'))
                      ->columns($db->quoteName($columns))
                      ->values(implode(',', $values));

                $db->setQuery($query);
                $db->execute();

                if(isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
                    $file = $_FILES['product_image'];
                    $config = hikashop_config();
                    $uploadFolder = $config->get('uploadfolder');
                    if(empty($uploadFolder)) {
                        $uploadFolder = 'media/com_hikashop/upload/';
                    }
                    
                    $uploadPath = JPATH_ROOT . '/' . trim($uploadFolder, '/') . '/';
                    $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $file['name']);
                    
                    if(move_uploaded_file($file['tmp_name'], $uploadPath . $fileName)) {
                        $query = $db->getQuery(true);
                        $columns = array(
                            'file_ref_id',
                            'file_name',
                            'file_description',
                            'file_path',
                            'file_type',
                            'file_ordering'
                        );
                        $values = array(
                            $product_id,
                            $db->quote($fileName),
                            $db->quote(''),
                            $db->quote($fileName),
                            $db->quote('product'),
                            0
                        );

                        $query->insert($db->quoteName('#__hikashop_file'))
                              ->columns($db->quoteName($columns))
                              ->values(implode(',', $values));

                        $db->setQuery($query);
                        $db->execute();
                    }
                }

                $query = $db->getQuery(true);
                $columns = array('product_id', 'category_id', 'ordering');
                $values = array($product_id, 2, 0);

                $query->insert($db->quoteName('#__hikashop_product_category'))
                      ->columns($db->quoteName($columns))
                      ->values(implode(',', $values));

                $db->setQuery($query);
                $db->execute();

                $app->enqueueMessage('Ürün başarıyla eklendi! (ID: '.$product_id.')', 'message');
            } else {
                throw new Exception('Ürün eklenemedi');
            }

        } catch (Exception $e) {
            $app->enqueueMessage('Hata: ' . $e->getMessage(), 'error');
            $app->enqueueMessage('Hata Dosyası: ' . $e->getFile(), 'error');
            $app->enqueueMessage('Hata Satırı: ' . $e->getLine(), 'error');
            $app->enqueueMessage('Hata İzi: ' . $e->getTraceAsString(), 'error');
        }
    }
}
