<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/helper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ModAddProductHelper::addProduct($_POST);
}

require JModuleHelper::getLayoutPath('mod_add_product');
