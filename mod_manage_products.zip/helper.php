<?php
class ModManageProductsHelper {
    public static function getProducts() {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        
        $query->select('p.*, pr.price_value')
              ->from($db->quoteName('#__hikashop_product', 'p'))
              ->leftJoin(
                  $db->quoteName('#__hikashop_price', 'pr') . 
                  ' ON ' . $db->quoteName('p.product_id') . ' = ' . $db->quoteName('pr.price_product_id')
              )
              ->where($db->quoteName('p.product_type') . ' = ' . $db->quote('main'))
              ->order($db->quoteName('p.product_id') . ' DESC');
        
        $db->setQuery($query);
        return $db->loadObjectList();
    }

    public static function deleteProduct($product_id) {
        $app = JFactory::getApplication();
        $db = JFactory::getDbo();
        
        try {
            // Start transaction
            $db->transactionStart();

            // First check if product exists
            $query = $db->getQuery(true)
                ->select('product_id')
                ->from($db->quoteName('#__hikashop_product'))
                ->where($db->quoteName('product_id') . ' = ' . (int)$product_id);
            
            $db->setQuery($query);
            if (!$db->loadResult()) {
                throw new Exception('Ürün bulunamadı.');
            }

            // Delete price records
            $query = $db->getQuery(true);
            $query->delete($db->quoteName('#__hikashop_price'))
                  ->where($db->quoteName('price_product_id') . ' = ' . (int)$product_id);
            $db->setQuery($query);
            $db->execute();

            // Delete product
            $query = $db->getQuery(true);
            $query->delete($db->quoteName('#__hikashop_product'))
                  ->where($db->quoteName('product_id') . ' = ' . (int)$product_id);
            $db->setQuery($query);
            $db->execute();

            // Commit transaction
            $db->transactionCommit();
            $app->enqueueMessage('Ürün başarıyla silindi.');
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->transactionRollback();
            $app->enqueueMessage('Ürün silinirken bir hata oluştu: ' . $e->getMessage(), 'error');
        }
    }

    public static function updateProduct($data) {
        $app = JFactory::getApplication();
        $db = JFactory::getDbo();
        
        try {
            // Start transaction
            $db->transactionStart();

            // First check if product exists
            $query = $db->getQuery(true)
                ->select('product_id')
                ->from($db->quoteName('#__hikashop_product'))
                ->where($db->quoteName('product_id') . ' = ' . (int)$data['product_id']);
            
            $db->setQuery($query);
            if (!$db->loadResult()) {
                throw new Exception('Güncellenecek ürün bulunamadı.');
            }

            // Validate required fields
            if (empty($data['product_name']) || !isset($data['product_quantity']) || !isset($data['product_price'])) {
                throw new Exception('Lütfen tüm gerekli alanları doldurun.');
            }

            // Update product details
            $query = $db->getQuery(true);
            $fields = array(
                $db->quoteName('product_name') . ' = ' . $db->quote($data['product_name']),
                $db->quoteName('product_description') . ' = ' . $db->quote($data['product_description']),
                $db->quoteName('product_quantity') . ' = ' . (int)$data['product_quantity']
            );

            $query->update($db->quoteName('#__hikashop_product'))
                  ->set($fields)
                  ->where($db->quoteName('product_id') . ' = ' . (int)$data['product_id']);

            $db->setQuery($query);
            $db->execute();

            // Check if price record exists
            $query = $db->getQuery(true)
                ->select('price_id')
                ->from($db->quoteName('#__hikashop_price'))
                ->where($db->quoteName('price_product_id') . ' = ' . (int)$data['product_id']);
            
            $db->setQuery($query);
            $priceExists = $db->loadResult();

            if ($priceExists) {
                // Update existing price
                $query = $db->getQuery(true);
                $fields = array(
                    $db->quoteName('price_value') . ' = ' . (float)$data['product_price']
                );

                $query->update($db->quoteName('#__hikashop_price'))
                      ->set($fields)
                      ->where($db->quoteName('price_product_id') . ' = ' . (int)$data['product_id']);
            } else {
                // Insert new price
                $query = $db->getQuery(true);
                $columns = array('price_product_id', 'price_value');
                $values = array((int)$data['product_id'], (float)$data['product_price']);

                $query->insert($db->quoteName('#__hikashop_price'))
                      ->columns($db->quoteName($columns))
                      ->values(implode(',', $values));
            }

            $db->setQuery($query);
            $db->execute();

            // Commit transaction
            $db->transactionCommit();
            $app->enqueueMessage('Ürün başarıyla güncellendi.');
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->transactionRollback();
            $app->enqueueMessage('Ürün güncellenirken bir hata oluştu: ' . $e->getMessage(), 'error');
        }
    }
}
