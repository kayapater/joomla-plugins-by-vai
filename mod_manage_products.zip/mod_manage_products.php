<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/helper.php';

$products = ModManageProductsHelper::getProducts();

$input = JFactory::getApplication()->input;
$task = $input->getString('task');
$product_id = $input->getInt('product_id');

if ($task === 'delete' && $product_id > 0) {
    try {
        ModManageProductsHelper::deleteProduct($product_id);
        $app = JFactory::getApplication();
        $app->redirect(JUri::current());
        return;
    } catch (Exception $e) {
        JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
    }
}

if ($task === 'update' && $product_id > 0) {
    try {
        ModManageProductsHelper::updateProduct($input->post->getArray());
        $app = JFactory::getApplication();
        $app->redirect(JUri::current());
        return;
    } catch (Exception $e) {
        JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
    }
}

require JModuleHelper::getLayoutPath('mod_manage_products');
