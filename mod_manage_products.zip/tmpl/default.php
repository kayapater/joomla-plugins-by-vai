<?php
// No direct access
defined('_JEXEC') or die;
?>

<div class="manage-products">
    <h3>Ürün Yönetimi</h3>
    
    <?php if (empty($products)) : ?>
        <p>Henüz ürün bulunmamaktadır.</p>
    <?php else : ?>
        <div class="products-grid">
            <?php foreach ($products as $product) : ?>
                <div class="product-card" id="product-<?php echo $product->product_id; ?>">
                    <div class="product-info">
                        <h4><?php echo htmlspecialchars($product->product_name); ?></h4>
                        <p class="stock">Stok: <?php echo $product->product_quantity; ?></p>
                        <p class="price">Fiyat: <?php echo number_format($product->price_value, 2); ?> ₺</p>
                    </div>
                    
                    <div class="product-actions">
                        <button onclick="showEditForm(<?php echo htmlspecialchars(json_encode($product)); ?>)" class="edit-btn">Düzenle</button>
                        
                        <form action="<?php echo JUri::current(); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Bu ürünü silmek istediğinizden emin misiniz?')">
                            <?php echo JHtml::_('form.token'); ?>
                            <input type="hidden" name="task" value="delete">
                            <input type="hidden" name="product_id" value="<?php echo $product->product_id; ?>">
                            <button type="submit" class="delete-btn">Sil</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Edit Form Modal -->
        <div id="editModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h4>Ürün Düzenle</h4>
                <form action="<?php echo JUri::current(); ?>" method="POST" id="editForm">
                    <?php echo JHtml::_('form.token'); ?>
                    <input type="hidden" name="task" value="update">
                    <input type="hidden" name="product_id" id="edit_product_id">
                    
                    <div class="form-group">
                        <label for="edit_product_name">Ürün Adı:</label>
                        <input type="text" id="edit_product_name" name="product_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_product_description">Açıklama:</label>
                        <textarea id="edit_product_description" name="product_description" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_product_quantity">Stok:</label>
                        <input type="number" id="edit_product_quantity" name="product_quantity" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_product_price">Fiyat (₺):</label>
                        <input type="number" step="0.01" id="edit_product_price" name="product_price" min="0" required>
                    </div>
                    
                    <button type="submit" class="save-btn">Kaydet</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.manage-products {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.product-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.product-info h4 {
    margin: 0 0 10px 0;
    color: #333;
}

.product-info p {
    margin: 5px 0;
    color: #666;
}

.product-info .price {
    font-weight: bold;
    color: #2196F3;
}

.product-actions {
    margin-top: 15px;
    display: flex;
    gap: 10px;
}

button {
    padding: 8px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
}

.edit-btn {
    background: #2196F3;
    color: white;
}

.delete-btn {
    background: #f44336;
    color: white;
}

.save-btn {
    background: #4CAF50;
    color: white;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 500px;
    border-radius: 8px;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.form-group textarea {
    height: 100px;
}
</style>

<script>
function showEditForm(product) {
    document.getElementById('edit_product_id').value = product.product_id;
    document.getElementById('edit_product_name').value = product.product_name;
    document.getElementById('edit_product_description').value = product.product_description;
    document.getElementById('edit_product_quantity').value = product.product_quantity;
    document.getElementById('edit_product_price').value = product.price_value;
    
    var modal = document.getElementById('editModal');
    modal.style.display = "block";
}

// Get the modal
var modal = document.getElementById('editModal');

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
