<?php
// No direct access
defined('_JEXEC') or die;

$doc = JFactory::getDocument();
$doc->addStyleDeclaration('
    .modal-backdrop {
        background-color: rgba(0,0,0,0.5);
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9998;
    }
    .user-modal {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 70%;
        max-width: 700px;
        max-height: 80vh;
        overflow-y: auto;
        z-index: 9999;
        background: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    .hikashop-usermanager {
        position: relative;
        z-index: 1;
    }
    .order-status-confirmed { color: #28a745; font-weight: bold; }
    .order-status-pending { color: #ffc107; font-weight: bold; }
    .order-status-cancelled { color: #dc3545; font-weight: bold; }
    .order-item { 
        background: #f8f9fa;
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .order-products ul { 
        list-style: none; 
        padding-left: 0; 
        margin: 8px 0;
    }
    .order-products li { 
        background: white;
        padding: 6px 10px;
        margin-bottom: 4px;
        border-radius: 4px;
        border-left: 4px solid #007bff;
    }
    .user-info-card {
        padding: 15px;
    }
    .user-info-card h5 {
        font-size: 1.1em;
        color: #007bff;
        border-bottom: 2px solid #007bff;
        padding-bottom: 10px;
        margin-bottom: 15px;
    }
    .shipping-address {
        background: #e9ecef;
        padding: 8px 12px;
        border-radius: 4px;
        margin-top: 8px;
    }
    .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    .order-price {
        font-size: 1.1em;
        font-weight: bold;
        color: #28a745;
    }
    .order-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        position: relative;
        z-index: 0;
    }
    .btn-manage-order {
        background-color: #fd7e14;
        color: white !important;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 0.9em;
        text-decoration: none !important;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        transition: all 0.2s ease;
        user-select: none;
    }
    .modal-header {
        padding: 12px 15px;
        border-bottom: 1px solid #dee2e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .modal-header h4 {
        font-size: 1.2em;
        margin: 0;
        color: #007bff;
    }
    .modal-body {
        padding: 15px;
        max-height: calc(80vh - 100px);
        overflow-y: auto;
    }
    .close-modal {
        font-size: 24px;
        font-weight: bold;
        color: #666;
        cursor: pointer;
        background: none;
        border: none;
        padding: 0;
    }
    .close-modal:hover {
        color: #000;
    }
');

$doc->addScriptDeclaration('
    function showUserDetails(userId) {
        var modal = document.getElementById("user-modal-" + userId);
        var backdrop = document.getElementById("modal-backdrop");
        if (modal && backdrop) {
            modal.style.display = "block";
            backdrop.style.display = "block";
            document.body.style.overflow = "hidden";
        }
    }

    function closeUserDetails(userId) {
        var modal = document.getElementById("user-modal-" + userId);
        var backdrop = document.getElementById("modal-backdrop");
        if (modal && backdrop) {
            modal.style.display = "none";
            backdrop.style.display = "none";
            document.body.style.overflow = "auto";
        }
    }

    // Backdrop tıklaması ile modalı kapat
    document.addEventListener("DOMContentLoaded", function() {
        var backdrop = document.getElementById("modal-backdrop");
        if (backdrop) {
            backdrop.addEventListener("click", function() {
                var modals = document.getElementsByClassName("user-modal");
                for (var i = 0; i < modals.length; i++) {
                    modals[i].style.display = "none";
                }
                backdrop.style.display = "none";
                document.body.style.overflow = "auto";
            });
        }
    });

    function goToOrderManagement(orderId) {
        window.open("/kayadan/index.php/adminpanel/siparis-yonetim-sistemi?order_id=" + orderId, "_blank");
        return false;
    }
');

// Font Awesome ekle
$doc->addCustomTag('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">');
?>

<div class="hikashop-usermanager">
    <div id="modal-backdrop" class="modal-backdrop"></div>
    
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>İsim</th>
                <th>Kullanıcı Adı</th>
                <th>E-posta</th>
                <th>Toplam Sipariş</th>
                <th>Kayıt Tarihi</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($users)) : ?>
                <?php foreach ($users as $user) : ?>
                <tr>
                    <td><?php echo $user->id; ?></td>
                    <td><?php echo $user->name; ?></td>
                    <td><?php echo $user->username; ?></td>
                    <td><?php echo $user->email; ?></td>
                    <td><?php echo (int)$user->total_orders; ?></td>
                    <td><?php echo JHtml::_('date', $user->registerDate, JText::_('DATE_FORMAT_LC4')); ?></td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="showUserDetails(<?php echo $user->id; ?>)">
                            <i class="fas fa-info-circle"></i> Detaylar
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">Henüz kayıtlı kullanıcı bulunmamaktadır.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php 
    // Base URL'yi al
    $uri = JUri::base();
    $adminUrl = str_replace('/administrator', '', $uri);
    ?>

    <?php if (!empty($users)) : ?>
        <?php foreach ($users as $user) : ?>
        <div id="user-modal-<?php echo $user->id; ?>" class="user-modal">
            <div class="modal-header">
                <h4><i class="fas fa-user"></i> <?php echo $user->name; ?> - Kullanıcı Detayları</h4>
                <button type="button" class="close-modal" onclick="closeUserDetails(<?php echo $user->id; ?>)">&times;</button>
            </div>
            <div class="modal-body">
                <div class="user-info-card">
                    <h5><i class="fas fa-info-circle"></i> Kullanıcı Bilgileri</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><i class="fas fa-user-circle"></i> <strong>Ad Soyad:</strong> <?php echo $user->address_firstname . ' ' . $user->address_lastname; ?></p>
                            <p><i class="fas fa-map-marker-alt"></i> <strong>Adres:</strong> <?php echo $user->address_street; ?></p>
                            <p><i class="fas fa-city"></i> <strong>Şehir:</strong> <?php echo $user->address_city; ?></p>
                            <p><i class="fas fa-phone"></i> <strong>Telefon:</strong> <?php echo $user->address_telephone; ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><i class="fas fa-calendar-alt"></i> <strong>Kayıt Tarihi:</strong> <?php echo JHtml::_('date', $user->registerDate, JText::_('DATE_FORMAT_LC4')); ?></p>
                            <p><i class="fas fa-shopping-cart"></i> <strong>Toplam Sipariş:</strong> <?php echo (int)$user->total_orders; ?></p>
                        </div>
                    </div>

                    <h5 class="mt-4"><i class="fas fa-shopping-cart"></i> Siparişler</h5>
                    <?php if (!empty($user->orders)) : ?>
                        <?php foreach ($user->orders as $order) : ?>
                            <div class="order-item">
                                <div class="order-header">
                                    <div class="order-actions">
                                        <h6>
                                            <i class="fas fa-box"></i> Sipariş #<?php echo $order->order_number; ?> - 
                                            <span class="order-status-<?php echo strtolower($order->order_status); ?>">
                                                <?php echo ucfirst($order->order_status); ?>
                                            </span>
                                        </h6>
                                        <button class="btn-manage-order" onclick="handleManageOrderClick()">Siparişi Yönet</button>
                                    </div>
                                    <span class="order-price">
                                        <?php echo number_format($order->order_full_price, 2, ',', '.') . ' ₺'; ?>
                                    </span>
                                </div>
                                <p>
                                    <i class="far fa-calendar-alt"></i> <strong>Tarih:</strong> 
                                    <?php echo JHtml::_('date', $order->order_created, JText::_('DATE_FORMAT_LC4')); ?>
                                </p>
                                
                                <?php if (!empty($order->products)) : ?>
                                    <div class="order-products">
                                        <strong><i class="fas fa-list"></i> Ürünler:</strong>
                                        <ul>
                                        <?php foreach ($order->products as $product) : ?>
                                            <li>
                                                <i class="fas fa-cube"></i> <?php echo $product->product_name; ?> 
                                                <span class="float-right">
                                                    <?php echo $product->order_product_quantity; ?> adet x 
                                                    <?php echo number_format($product->order_product_price, 2, ',', '.') . ' ₺'; ?>
                                                </span>
                                            </li>
                                        <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($order->shipping_address)) : ?>
                                    <div class="shipping-address">
                                        <i class="fas fa-truck"></i> <strong>Teslimat Adresi:</strong><br>
                                        <?php echo $order->shipping_address->address_firstname . ' ' . $order->shipping_address->address_lastname; ?><br>
                                        <?php echo $order->shipping_address->address_street; ?><br>
                                        <?php echo $order->shipping_address->address_city; ?><br>
                                        <?php echo $order->shipping_address->address_telephone; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted"><i class="fas fa-info-circle"></i> Henüz sipariş bulunmamaktadır.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function handleManageOrderClick() {
    console.log('Siparişi Yönet butonuna tıklandı.');
    window.open('/index.php/admin/siparis-yonetim', '_blank');
}
</script>
