<?php
defined('_JEXEC') or die;

class ModHikashopUsermanagerHelper
{
    public static function getUsers()
    {
        $db = JFactory::getDbo();
        
        $query = $db->getQuery(true);
        $query->select('DISTINCT u.id, u.name, u.username, u.email, u.registerDate')
              ->from($db->quoteName('#__users', 'u'))
              ->order('u.id DESC');
        
        $db->setQuery($query);
        $users = $db->loadObjectList('id');
        
        if (!empty($users)) {
            foreach ($users as $user) {
                $query = $db->getQuery(true);
                $query->select('COUNT(o.order_id)')
                      ->from($db->quoteName('#__hikashop_order', 'o'))
                      ->join('LEFT', $db->quoteName('#__hikashop_user', 'hu') . ' ON ' .
                             $db->quoteName('o.order_user_id') . ' = ' . $db->quoteName('hu.user_id'))
                      ->where('hu.user_cms_id = ' . (int)$user->id);
                
                $db->setQuery($query);
                $user->total_orders = (int)$db->loadResult();
            }
        }
        
        return array_values($users);
    }

    public static function getUserDetails($userId)
    {
        $db = JFactory::getDbo();
        
        $query = $db->getQuery(true);
        $query->select('u.*, hu.user_id as hikashop_user_id')
              ->from($db->quoteName('#__users', 'u'))
              ->join('LEFT', $db->quoteName('#__hikashop_user', 'hu') . ' ON ' .
                     $db->quoteName('u.id') . ' = ' . $db->quoteName('hu.user_cms_id'))
              ->where('u.id = ' . (int)$userId);
        
        $db->setQuery($query);
        $result = $db->loadObject();
        
        if ($result) {
            $query = $db->getQuery(true);
            $query->select('o.*')
                  ->from($db->quoteName('#__hikashop_order', 'o'))
                  ->where('o.order_user_id = ' . (int)$result->hikashop_user_id)
                  ->order('o.order_created DESC');
            
            $db->setQuery($query);
            $orders = $db->loadObjectList();
            
            $totalSpent = 0;
            if (!empty($orders)) {
                foreach ($orders as $order) {
                    if ($order->order_status !== 'cancelled') {
                        $totalSpent += floatval($order->order_full_price);
                    }
                }
            }
            
            $result->total_spent = $totalSpent;
            
            return array('user' => $result, 'orders' => $orders);
        }
        
        return false;
    }

    public static function getUserOrders($userId)
    {
        $db = JFactory::getDbo();
        
        $query = $db->getQuery(true)
            ->select('user_id')
            ->from($db->quoteName('#__hikashop_user'))
            ->where('user_cms_id = ' . (int)$userId);
        
        $db->setQuery($query);
        $hikashop_user_id = $db->loadResult();
        
        $query = $db->getQuery(true);
        $query->select('o.*, a.address_firstname, a.address_lastname, a.address_street, a.address_city, a.address_telephone')
              ->from($db->quoteName('#__hikashop_order', 'o'))
              ->join('LEFT', $db->quoteName('#__hikashop_address', 'a') . ' ON ' .
                     $db->quoteName('o.order_shipping_address_id') . ' = ' . $db->quoteName('a.address_id'))
              ->where('o.order_user_id = ' . (int)$hikashop_user_id)
              ->order('o.order_created DESC');
        
        $db->setQuery($query);
        $orders = $db->loadObjectList();
        
        if (!empty($orders)) {
            foreach ($orders as &$order) {
                $query = $db->getQuery(true);
                $query->select('op.*, p.product_name, p.product_code')
                      ->from($db->quoteName('#__hikashop_order_product', 'op'))
                      ->join('LEFT', $db->quoteName('#__hikashop_product', 'p') . ' ON ' .
                             $db->quoteName('op.product_id') . ' = ' . $db->quoteName('p.product_id'))
                      ->where('op.order_id = ' . (int)$order->order_id);
                
                $db->setQuery($query);
                $order->products = $db->loadObjectList();

                if (!empty($order->address_firstname)) {
                    $order->shipping_address = (object)[
                        'address_firstname' => $order->address_firstname,
                        'address_lastname' => $order->address_lastname,
                        'address_street' => $order->address_street,
                        'address_city' => $order->address_city,
                        'address_telephone' => $order->address_telephone
                    ];
                }
            }
        }
        
        return $orders;
    }
}
