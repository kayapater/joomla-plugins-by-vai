<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/helper.php';

$users = ModHikashopUsermanagerHelper::getUsers();

foreach ($users as &$user) {
    $user->orders = ModHikashopUsermanagerHelper::getUserOrders($user->id);
}

require JModuleHelper::getLayoutPath('mod_hikashop_usermanager', $params->get('layout', 'default'));
